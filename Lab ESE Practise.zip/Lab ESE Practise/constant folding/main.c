#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define MAX 50

typedef struct {
    char op[3];
    char arg1[10];
    char arg2[10];
    char result[10];
} quaduples;
int n,k;
quaduples mainQuad[MAX], optimizedQuad[MAX];

int isConstant(char *str) {
    for(int i =0; str[i]; i++){
        //if not equal to digit return 0;
        if(!isdigit(str[i])) {
            return 0;
        } 
    }
    //return 1 if it is number
    return 1;
}



int main() {
    printf("Enter the no. of Quads:\n");
    scanf("%d",&n);
    printf("Enter the quads in the following format\nOp\tArg1\tArg2\tResult:\n");
    for(int i = 0; i<n; i++) {
        scanf("%s %s %s %s", mainQuad[i].op ,mainQuad[i].arg1 ,mainQuad[i].arg2, mainQuad[i].result);
    }
    
    for(int i = 0; i<n; i++) {
        if((strcmp(mainQuad[i].op,"+") == 0 ||
           strcmp(mainQuad[i].op,"-") == 0 ||
           strcmp(mainQuad[i].op,"*") == 0 ||
           strcmp(mainQuad[i].op,"/") == 0) && isConstant(mainQuad[i].arg1) &&
           isConstant(mainQuad[i].arg2)){
          int a = atoi(mainQuad[i].arg1);
          int b = atoi(mainQuad[i].arg2);
          int res = 0;
          strcpy(optimizedQuad[i].result, mainQuad[i].result);
          if(strcmp(mainQuad[i].op, "+") == 0) {
            res = a+b;
          } else if(strcmp(mainQuad[i].op, "-") == 0) {
            res = a-b;
          } else if(strcmp(mainQuad[i].op, "*") == 0) {
            res = a*b;
          } else if(strcmp(mainQuad[i].op, "/") == 0) {
            res = a/b;
          }
          strcpy(optimizedQuad[i].op,"=");
          sprintf(optimizedQuad[i].arg1,"%d",res);
          strcpy(optimizedQuad[i].arg2,".");
          strcpy(optimizedQuad[i].result,mainQuad[i].result);
        } else {
            optimizedQuad[i] = mainQuad[i];
        }
    }

    printf("Main Quad: \n");
    printf("Op\tArg1\tArg2\tResult:\n");
    for(int i = 0; i<n; i++) {
        printf("%s\t%s\t%s\t%s\n",mainQuad[i].op, mainQuad[i].arg1, mainQuad[i].arg2,mainQuad[i].result);
    }
    printf("Optimized Quad(Constant folding): \n");
    printf("Op\tArg1\tArg2\tResult:\n");
    for(int i = 0; i<n; i++) {
        printf("%s\t%s\t%s\t%s\n",optimizedQuad[i].op, optimizedQuad[i].arg1, optimizedQuad[i].arg2,optimizedQuad[i].result);
    }

    return 0;
}