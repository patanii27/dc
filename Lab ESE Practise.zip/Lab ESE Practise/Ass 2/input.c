#include <stdio.h>

int main() {
    int a = 5;
    float b = 6.7;
    a = a + b;
    if (a > 5) {
        printf("no>5\n");
    }
    return 0;
}
