%{
#include <stdio.h>
#include <stdlib.h>

int yylex();
void yyerror(const char *s);
%}

%token NUMBER VARIABLE PLUS MINUS TIMES DIVIDE
%token  EOL


%%

program:
     program expr EOL   {printf("Result = %d",$2);}
  |
  ;

expr:
     NUMBER    { $$ = $1; }  
  |  VARIABLE  {printf("Variable '%c' accessed\n",$1);  $$ = 0;}
  |  expr PLUS expr   {printf("The arthemetic expression %d + %d is valid.\n",$1, $3); $$ = $1 + $3; }
  |  expr MINUS expr  {printf("The arthemetic expression %d - %d is valid.\n",$1, $3);$$ = $1 - $3; }
  |  expr TIMES expr  {printf("The arthemetic expression %d * %d is valid.\n",$1, $3);$$ = $1 * $3; }
  |  expr DIVIDE expr  {printf("The arthemetic expression %d / %d is valid.\n",$1, $3);$$ = $1 / $3; }
  |
  ;

%%

int main() {
    return yyparse();  // This starts the parsing
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}