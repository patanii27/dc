CREATE TABLE Students (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT
);

INSERT INTO Students (id, name, age) VALUES (1, 'Soham', 20);

SELECT * FROM Students;