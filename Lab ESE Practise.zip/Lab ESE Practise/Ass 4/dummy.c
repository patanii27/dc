#include <stdio.h>
#include <string.h>

int isNoun(char word[]);
int isVerb(char word[]);
int isArticle(char word[]);
int isPronoun(char word[]);
int isAdverb(char word[]);


int main() {
    int yytext;
    int lineNo;
        if(isNoun(yytext)){
        printf("%-10d %-20d %-20d\n",lineNo,"Noun",yytext);
        }
        else if(isPronoun(yytext)){
            printf("%-10d %-20d %-20d\n",lineNo,"Pronoun",yytext);
        }
        else if(isAdverb(yytext)){
            printf("%-10d %-20d %-20d\n",lineNo,"Adverb",yytext);
        }
        else if(isArticle(yytext)){
            printf("%-10d %-20d %-20d\n",lineNo,"Article",yytext);
        }
        else if(isVerb(yytext)){
            printf("%-10d %-20d %-20d\n",lineNo,"Verb",yytext);
        }
        else if(isPreposition(yytext)){
            printf("%-10d %-20d %-20d\n",lineNo,"Preposition",yytext);
        }
}

int isNoun(char word[]){
    char *nouns[] = {"dog","cat","fox","Soham","Dachawar","school","Pune","Burger","Book",NULL};
    for(int i = 0; nouns[i]!= NULL; i++ ){
       if(strcmp(word,nouns[i]) == 0) {
        return 1;
       }
    }
    return 0;
}

int isPronoun(char word[]){
    char *pronoun[] = {"is","he","she","they","us","him","her","we","them","",NULL};
    for(int i = 0; pronoun[i]!= NULL; i++ ){
       if(strcmp(word,pronoun[i]) == 0) {
        return 1;
       }
    }
    return 0;
}
int isArticle(char word[]){
    char *articles[] = {"A","a","The","the","An","an",NULL};
    for(int i = 0; articles[i]!= NULL; i++ ){
       if(strcmp(word,articles[i]) == 0) {
        return 1;
       }
    }
    return 0;
}
int isVerb(char word[]){
    char *verbs[] = {"eat","sit","play","dance","jumped","quick","eating","singing","studying","playing","jumping","dancing","crying","running","is","am","are","wad","were","can","could","shall","should",NULL};
    for(int i = 0; verbs[i]!= NULL; i++ ){
       if(strcmp(word,verbs[i]) == 0) {
        return 1;
       }
    }
    return 0;
}
int isAdverb(char word[]){
    char *adverbs[] = {"brown","black","quick","slow","fast","lazy","smart","",NULL};
    for(int i = 0; adverbs[i]!= NULL; i++ ){
       if(strcmp(word,adverbs[i]) == 0) {
        return 1;
       }
    }
    return 0;
}
