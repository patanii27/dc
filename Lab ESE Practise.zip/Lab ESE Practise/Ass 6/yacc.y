%{
#include <stdio.h>
#include <stdlib.h>
void yyerror(const char *s);
int yylex();
%}

%token WHILE PRINT VARIABLE NUMBER GT LT EQ LPAREN RPAREN LBRACE RBRACE SEMICOL

%%

program:
    program statement
  | /* empty */
  ;

statement:
    WHILE LPAREN condition RPAREN LBRACE statements RBRACE
        { printf("Parsed: while loop\n"); }

  | PRINT LPAREN VARIABLE RPAREN SEMICOL
        { printf("Parsed: printf statement\n"); }

  | VARIABLE EQ NUMBER SEMICOL
        { printf("Parsed: assignment\n"); }

  ;

statements:
    statement
  | statements statement
  ;

condition:
    VARIABLE GT NUMBER
  | VARIABLE LT NUMBER
  | VARIABLE EQ NUMBER
  ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Parse error: %s\n", s);
}

int main() {
    yyparse();
    return 0;
}