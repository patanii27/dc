int main()
{
    x = 7 * 2;
    y = 20 / 4;
    z = x - y;
}