while(a)
{
fghji;
}
