%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int yylex();
void yyerror(const char *msg);

typedef struct Node {
    char *name;
    struct Node *left, *right;
} Node;

Node* createNode(const char *name, Node *left, Node *right) {
    Node *node = (Node *)malloc(sizeof(Node));
    if (!node) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    node->name = strdup(name);
    node->left = left;
    node->right = right;
    return node;
}

void printTree(Node *root, int level) {
    if (!root) return;
    for (int i = 0; i < level; i++) printf("  ");
    printf("|-- %s\n", root->name);
    printTree(root->left, level + 1);
    printTree(root->right, level + 1);
}

Node *root;
%}

%union {
    struct Node *node;
    char *string;
}

%token LPAREN RPAREN ADD SUB MUL DIV ID NUMBER
%type <node> expr term factor
%type <string> ID NUMBER

%%

program: expr {
            root = $1;
            printf("Valid expression\n");
            printTree(root, 0);
        }
       ;

expr: expr ADD term { $$ = createNode("+", $1, $3); }
    | expr SUB term { $$ = createNode("-", $1, $3); }
    | term { $$ = $1; }
    ;

term: term MUL factor { $$ = createNode("*", $1, $3); }
    | term DIV factor { $$ = createNode("/", $1, $3); }
    | factor { $$ = $1; }
    ;

factor: NUMBER { $$ = createNode($1, NULL, NULL); }
      | ID { $$ = createNode($1, NULL, NULL); }
      | LPAREN expr RPAREN { $$ = $2; }
      ;

%%

void yyerror(const char *msg) {
    printf("Syntax Error: %s\n", msg);
}

int main() {
    printf("Enter an arithmetic expression:\n");
    yyparse();
    return 0;
}
