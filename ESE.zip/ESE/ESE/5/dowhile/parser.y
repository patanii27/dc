%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.tab.h"
void yyerror(const char *s);
int yylex();
void print_indent(int level);
int indent = 0; // Global indent level
%}

%union {
    char* str;    // for ID and others
}

%token <str> ID NUMBER
%token DO WHILE LPAREN RPAREN LBRACE RBRACE ASSIGN SEMICOLON LT PLUS

// Define precedence to avoid shift/reduce conflicts
%left PLUS
%left LT

%%

program:
    do_while_stmt {
        indent++;
        indent--;
    }
    ;

do_while_stmt:
    DO LBRACE stmt_list RBRACE WHILE LPAREN condition RPAREN SEMICOLON {
        print_indent(indent);
        printf("|-- do_while_stmt\n");
        indent++;
        print_indent(indent);
        printf("|-- DO\n");
        indent++;
        print_indent(indent);
        printf("|-- stmt_list\n");
        indent++;
        // stmt_list prints its content here
        indent--;
        print_indent(indent);
        printf("|-- WHILE\n");
        print_indent(indent);
        printf("|-- condition\n");
        indent++;
        indent--;
    }
    ;

condition:
    expr LT expr {
        print_indent(indent);
        printf("|-- condition\n");
        indent++;
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        indent--;
        print_indent(indent);
        printf("|-- LT\n");
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        indent--;
    }
    ;

expr:
    expr PLUS expr {
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        indent--;
        print_indent(indent);
        printf("|-- PLUS\n");
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        indent--;
    }
    | ID {
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        print_indent(indent);
        printf("|-- ID: %s\n", $1);
        indent--;
    }
    | NUMBER {
        print_indent(indent);
        printf("|-- expr\n");
        indent++;
        print_indent(indent);
        printf("|-- NUMBER: %s\n", $1);
        indent--;
    }
    ;

stmt_list:
    stmt {
        print_indent(indent);
        printf("|-- stmt_list\n");
        indent++;
        print_indent(indent);
        printf("|-- stmt\n");
        indent--;
    }
    | stmt_list stmt {
        print_indent(indent);
        printf("|-- stmt_list\n");
        indent++;
        print_indent(indent);
        printf("|-- stmt\n");
        indent--;
    }
    ;

stmt:
    ID ASSIGN expr SEMICOLON {
        print_indent(indent);
        printf("|-- stmt\n");
        indent++;
        print_indent(indent);
        printf("|-- ID: %s\n", $1);
        print_indent(indent);
        printf("|-- ASSIGN\n");
        print_indent(indent);
        printf("|-- SEMICOLON\n");
        indent--;
    }
    ;

%%

void yyerror(const char *s) {
    printf("Error: %s\n", s);
}

void print_indent(int level) {
    for (int i = 0; i < level; i++) {
        printf("    ");
    }
}

int main() {
    printf("Enter a do-while statement:\n");
    yyparse();
    return 0;
}
