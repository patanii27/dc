%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int line_number = 1;
%}

%%

[A-Z][a-z]+([[:space:]][A-Z][a-z]+)* { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid Name", yytext); 
}

[0-9]{10} { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid Mobile Number", yytext); 
}

(https?:\/\/)?(www\.)?[a-zA-Z0-9_-]+\.[a-zA-Z]+(\/[a-zA-Z0-9#_-]+)*\/? { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid URL", yytext); 
}

[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,} { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid Email", yytext); 
}

(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/([0-9]{4}) { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid Date", yytext); 
}

([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9] { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "Valid Time", yytext); 
}

[^ \t\n]+ { 
    printf("%-8d %-25s %-20s %s\n", line_number, yytext, "INVALID", yytext); 
}

\n { 
    line_number++; // Increment on each new line
}

%%

int main() {
    char filename[100];
    printf("Enter the input file name: ");
    scanf("%s", filename);

    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file: %s\n", filename);
        return 1;
    }

    printf("%-8s %-25s %-20s %s\n", "Line No", "Lexeme", "Token", "Token-Value");
    printf("----------------------------------------------------------------------------\n");

    yyin = file;
    yylex();
    fclose(file);
    return 0;
}
int yywrap() {
    return 1;
}
