#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX_QUADS 500
#define MAX_STR 100

typedef struct {
    char op[20];
    char arg1[MAX_STR];
    char arg2[MAX_STR];
    char result[MAX_STR];
    bool eliminated;
    bool is_leader;
} Quadruple;

Quadruple quad_list[MAX_QUADS];
int quad_count = 0;

bool readQuadsFromFile(const char* filename);
void printQuads(const char* title, bool show_eliminated);

bool readQuadsFromFile(const char* filename) {
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening Quad input file");
        return false;
    }
    printf("Reading Quads from %s...\n", filename);
    quad_count = 0;
    char line[100];

    while (fgets(line, sizeof(line), fp) && quad_count < MAX_QUADS) {
        line[strcspn(line, "\r\n")] = 0;
        if (strlen(line) == 0) continue;

        char* parts[4] = {NULL, NULL, NULL, NULL};
        char* current_pos = line;
        int part_index = 0;

        while(part_index < 4 && current_pos != NULL && *current_pos != '\0') {
            parts[part_index++] = current_pos;
            char* next_space = strchr(current_pos, ' ');
            if (next_space != NULL) {
                *next_space = '\0';
                current_pos = next_space + 1;
            } else {
                current_pos = NULL;
            }
        }

        if (parts[0]) {
            strncpy(quad_list[quad_count].op, parts[0], 19);
            quad_list[quad_count].op[19] = '\0';

            strncpy(quad_list[quad_count].arg1, (parts[1] && strcmp(parts[1], "-") != 0) ? parts[1] : "", MAX_STR - 1);
            quad_list[quad_count].arg1[MAX_STR - 1] = '\0';

            strncpy(quad_list[quad_count].arg2, (parts[2] && strcmp(parts[2], "-") != 0) ? parts[2] : "", MAX_STR - 1);
            quad_list[quad_count].arg2[MAX_STR - 1] = '\0';

            strncpy(quad_list[quad_count].result, (parts[3] && strcmp(parts[3], "-") != 0) ? parts[3] : "", MAX_STR - 1);
            quad_list[quad_count].result[MAX_STR - 1] = '\0';

            quad_list[quad_count].eliminated = false;
            quad_list[quad_count].is_leader = false;
            quad_count++;
        } else {
            fprintf(stderr, "Warning: Skipping malformed quad line (empty?): %s\n", line);
        }
    }

    fclose(fp);
    printf("Read %d quads.\n", quad_count);
    return true;
}

void printQuads(const char* title, bool show_eliminated) {
    printf("\n--- %s ---\n", title);
    printf("Nr | %-15s | %-25s | %-25s | %-25s | %s\n", "Op", "Arg1", "Arg2", "Result", show_eliminated ? "Status" : "");
    printf("---|-----------------|---------------------------|---------------------------|---------------------------|--------\n");
    if (quad_count == 0) {
        printf("(No Quads)\n");
    }
    int displayed_count = 0;
    for (int i = 0; i < quad_count; i++) {
        if (!quad_list[i].eliminated || show_eliminated) {
            displayed_count++;
            printf("%03d| %-15s | %-25s | %-25s | %-25s | %s\n", i + 1,
                   quad_list[i].op, quad_list[i].arg1, quad_list[i].arg2, quad_list[i].result,
                   show_eliminated ? (quad_list[i].eliminated ? "(Elim)" : "") : "");
        }
    }
    if (displayed_count == 0 && !show_eliminated) {
        printf("(No quads remaining after optimization)\n");
    }
    printf("-----------------------------------------------------------------------------------------------\n");
}

void deadCodeElimination() {
    printf("\nPerforming Dead Code Elimination...\n");
    bool changed = false;
    bool used[MAX_QUADS] = {false};
    
    for (int i = 0; i < quad_count; i++) {
        if (quad_list[i].eliminated) continue;
        if (strlen(quad_list[i].arg1) > 0) {
            for (int j = 0; j < quad_count; j++) {
                if (strcmp(quad_list[j].result, quad_list[i].arg1) == 0) used[j] = true;
            }
        }
        if (strlen(quad_list[i].arg2) > 0) {
            for (int j = 0; j < quad_count; j++) {
                if (strcmp(quad_list[j].result, quad_list[i].arg2) == 0) used[j] = true;
            }
        }
    }
    
    for (int i = 0; i < quad_count; i++) {
        if (quad_list[i].eliminated) continue;
        if (strlen(quad_list[i].result) > 0 && !used[i]) {
            quad_list[i].eliminated = true;
            changed = true;
            printf("  Eliminated dead code at Quad %d (%s %s %s %s)\n", i+1, quad_list[i].op, quad_list[i].arg1, quad_list[i].arg2, quad_list[i].result);
        }
    }
    if (!changed) printf("  No dead code found.\n");
    printf("----------------------------------------\n");
}

int main(int argc, char *argv[]) {
    const char* quad_filename = "input";

    if (argc > 1) {
        quad_filename = argv[1]; 
    }

    printf("--- Quadruple Optimizer (Dead Code Elimination Only) ---\n");

    if (!readQuadsFromFile(quad_filename)) {
        fprintf(stderr, "Failed to read quadruples from %s. Exiting.\n", quad_filename);
        return 1;
    }
    printQuads("Initial Quads Loaded", false);

    deadCodeElimination();
    
    printQuads("Optimized Quadruples (Dead Code Elimination)", false);
    return 0;
}