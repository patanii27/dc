%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);
extern int line_num;
void print_token(const char *lexeme, const char *token, const char *value);
void print_parse_node(const char *label, int level);
%}

%union {
    char *str;
}

%token <str> IDENTIFIER
%token <str> NUMBER
%token WHILE LPAREN RPAREN LBRACE RBRACE SEMICOLON
%type <str> expression statement

%start program

%%

program:
    WHILE LPAREN expression RPAREN LBRACE statement RBRACE {
        printf("\n--- PARSE TREE ---\n");
        print_parse_node("program", 0);
        print_parse_node("WHILE", 1);
        print_parse_node("(", 1);
        print_parse_node("expression", 1);
        print_parse_node($3, 2);
        print_parse_node(")", 1);
        print_parse_node("{", 1);
        print_parse_node("statement", 1);
        print_parse_node($6, 2);
        print_parse_node(";", 2);
        print_parse_node("}", 1);
        printf("\nParsing Successful!\n");
    }
;

expression:
    IDENTIFIER { $$ = strdup("IDENTIFIER"); }
  | NUMBER     { $$ = strdup("NUMBER"); }
;

statement:
    IDENTIFIER SEMICOLON { $$ = strdup("IDENTIFIER"); }
  | NUMBER SEMICOLON     { $$ = strdup("NUMBER"); }
;

%%

void print_parse_node(const char *label, int level) {
    for (int i = 0; i < level; i++) printf("|  ");
    printf("|-- %s\n", label);
}

void print_token(const char *lexeme, const char *token, const char *value) {
    printf("Line %-3d | %-15s | %-12s | %-10s\n", line_num, lexeme, token, value);
}

void yyerror(const char *s) {
    fprintf(stderr, "\nSyntax error at line %d: %s\n", line_num, s);
}

// ✅ Multiline input: ends on empty line
int main() {
    printf("Enter your full code (e.g., while(x){x;}), then press Enter TWICE when done:\n\n");

    // Read multi-line input into buffer
    char input[1000] = "";
    char line[256];

    while (fgets(line, sizeof(line), stdin)) {
        if (strcmp(line, "\n") == 0) break; // stop on blank line
        strcat(input, line);
    }

    // Write input to temporary file
    FILE *temp = fopen("temp_input.c", "w");
    fprintf(temp, "%s", input);
    fclose(temp);

    // Open file for parsing
    extern FILE *yyin;
    yyin = fopen("temp_input.c", "r");
    if (!yyin) {
        perror("Failed to open temp file");
        return 1;
    }

    yyparse();
    fclose(yyin);
    return 0;
}
